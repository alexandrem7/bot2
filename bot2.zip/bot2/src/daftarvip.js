const daftarvip = (prefix) => { 
	return `
	
*PREÇO DE LISTA VIP :*

-Rp. 15 > Acessar recursos ViP
-Rp. 35 > Recursos VIP + Insira o bot no seu grupo!

*SE QUER REGISTAR VIP :*

*Proprietário do bate-papo BOT :*

_wa.me//19842265891*_

 `
}
exports.daftarvip = daftarvip